from .core import updater


def start():
    updater.start_polling()
